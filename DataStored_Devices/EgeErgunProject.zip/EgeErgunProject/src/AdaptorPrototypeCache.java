import java.util.Hashtable;
//Create a class to get concrete classes from database and store them in a Hashtable.
//hazir cachede cachelenmlis bitane onun bi kopyasini vereyim sana diyor program
public class AdaptorPrototypeCache {

	
	 private static Hashtable<String, USBMemoryDevice> adaptorMap  = new Hashtable<String, USBMemoryDevice>();
	 //hastablenin icinde memory devicelari tutuyoruz, adaptor Map iliskilendime anlami
	 //bir repositorty bir depo hastable koleksiyon yapili
	 

	   public static USBMemoryDevice getAdaptor(String adaptorId) {
		   USBMemoryDevice cachedAdaptor = adaptorMap.get(adaptorId);//clonunu aliyor get adaptor yaratiyoruz. 
	      return (USBMemoryDevice) cachedAdaptor.clone();
	   }
	   
	   public static void loadCache() {//bir object yaratiyoruz ozelligini belirtiyoruz
	      //geri donen objecti atiyom degistirmek istersin repositorydekini gonderse sablonu bozmak zorunda kalirsin prototype 
		   //sayesinde bozmuyorsun kopyasini gonderiyor
	      FlashUSBAdaptor flashUSBAdaptor= new FlashUSBAdaptor();//adaptor sayesinde flash usb yaratiyoruz
	      adaptorMap.put("Flash",flashUSBAdaptor);


	      SmartCardAdaptor smartCardAdaptor = new SmartCardAdaptor();
	      adaptorMap.put("SmartCard",smartCardAdaptor);
	      
//farkli bi configurasyon istersen smartcard adaptor2 yi kullan
	      SmartCardAdaptor smartCardAdaptor2 = new SmartCardAdaptor();
	      
	      adaptorMap.put("SmartCard2",smartCardAdaptor2);


	   }
	
	
}
