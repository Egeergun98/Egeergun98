
public abstract class USBMemoryDevice implements Cloneable {

	public abstract void waitForDevice();
	
	public abstract void write(UserInfo userinfo);//bu methodlari implmement ediyor adaptor
	public abstract UserInfo read();
	public abstract void decryptData();
	public abstract void encryptData();
	public abstract void openFile(String url);
	public abstract void deleteFile(String url);
	//clonable olmak zorinda clonunu dondurdugumuz icin
	public abstract boolean verifyPIN(String pin);

	public abstract void close();
    //Create an abstract class implementing Clonable interface.usb memory devicein clonu var diger adaptor
	//classlari usb memory devicedan miras aliyor
	public Object clone() {
	      Object clone = null;
	      
	      try {
	         clone = super.clone();
	         
	      } catch (CloneNotSupportedException e) {
	         e.printStackTrace();
	      }
	      
	      return clone;
	   }

	
	
	
	
}
