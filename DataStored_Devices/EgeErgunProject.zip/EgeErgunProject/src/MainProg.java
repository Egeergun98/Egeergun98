import java.util.Optional;

public class MainProg {

	public static void main(String[] args) {
	
		
		ComputerSingleton computer = ComputerSingleton.createSingletonComputer();
		
		computer.useComputer();
		
		Optional<Integer> op;
		op= Optional.of(5);
		
		//bir fonksiyon geriye optional dondurdugunde geriye null dondurmemis oluyoruz icerigi olan veya olmayan bir method. null bir methodun
		//cagrilamayan bir seyidir o yuzden null pointer sevilmeyen yerlerde optional kullanilir
		//null object patternle ilgili bir sey denedim bi anlami yok aslinda son halinde cunku methodlarin icleri dolu suan null dondurmuyoz
		
		
	}

}
