
// Protoype Method PAttern
//bir tane factory class yaratiyoruz  onun factoryadaptoru olan create adaptor cagiriyoruz bana bir smartcard
//objecti geriye dondur diyoruz o bana smart kart objectinin belleklerde olanlardan bir tanesinin kopyasini
//geriye dondurmeyi sagliyor hazir cachede cachelenmis bi tane onun bi kopyasini vereyim sana diyor
public class USBAdaptorFactory {


	public USBAdaptorFactory() {//adaptor factory objecti yaraptigim anda cacheliycek
		AdaptorPrototypeCache.loadCache();//loadcache yapip bu objectleri yaratip bellege koyduk(hastable)
	}

	public USBMemoryDevice createAdaptor(String DeviceType) {
		// TODO Auto-generated constructor stub
		if (DeviceType.contentEquals("SmartCard")) {
			
			return AdaptorPrototypeCache.getAdaptor("SmartCard");//get adaptardeyince smardcardi adaptorun kopyasini veriyor
			//git daha once bellekde yaratmis oldugum prototiplerden birini yakala ve geri dondur
		} else if (DeviceType.contentEquals("Flash")) {
			
			return AdaptorPrototypeCache.getAdaptor("Flash");
		}
		return null;
	}

}


